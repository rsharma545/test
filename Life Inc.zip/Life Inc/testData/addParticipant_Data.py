class AddParticipantData:

    first_name = "User"
    last_name = "Test"
    medicaid = "123456"
