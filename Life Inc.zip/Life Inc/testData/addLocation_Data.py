class AddLocationData:

    location_name = "Test Location"
    address_line_1 = "Test Address/11"
    city = "Test City"
    state = "Test State"
    zip = "12345"

