class AddEmployeeData:
    employee_name='test rahul'
    employee_username='User Rahul'
    employee_password='Password@1'