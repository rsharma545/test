class LoginTestData:
    username = "support@getventive.com"
    password = "Ventive@2020"
    baseURL = "https://lifeinc-staging.ventive.app/sign-in"