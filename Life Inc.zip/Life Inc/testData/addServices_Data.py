class NewServicesData:
    service_code = '111111'
    unit_price = '10'
