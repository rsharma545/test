class DownloadX12CSR:

    locatorMenuApprovals = "//a[@href='/approvals?q=1']"
    locatorAllApprovals = "//a[@href='/approvals?q=all']"
    locatorWaitingForSubmission = "//div[text()='Waiting Submission']"
    locatorVerticalBtn = "(//span[@class='ant-dropdown-trigger material-icons gx-text-primary gx-pointer'])[2]"
    locatorDownloadX12 = "(//ul/li[@class='ant-dropdown-menu-item ant-dropdown-menu-item-only-child'])[3]"

