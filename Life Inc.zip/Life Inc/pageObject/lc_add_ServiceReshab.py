class NewServices:

    locatorSettings = "//div[text()='Settings']"
    locatorServices = "//a[@href='/services']"
    locatorAddService = "//span[text()='Add Service']"
    locatorProgram = "(//input[@class='ant-select-selection-search-input'])[2]"
    locatorPopupNext = "//span[text()='Next']"
    locatorServicesCode = "//input[@class='ant-input gx-mb-0 gx-w-100']"
    locatorUnit = "(//input[@class='ant-select-selection-search-input'])[3]"
    locatorUnitPrice = "//input[@name='price']"
    locatorPopupAddServices = "//button[@class='ant-btn ant-btn-primary']"
