class AddManualTEP:

    locatorMenuParticipants = "//a[@href='/participants']"
    locatorParticipant = "//a[@href='/participants/16']"
    locatorTimeEntry = "(//span[@class = 'gx-link tab--3MP0J'])[2]"
    locatorManualTimeEntry = "(//button[@class = 'ant-btn ant-btn-primary ant-btn-lg'])[2]"
    locatorCalendar = "//div[@class='ant-picker-input ant-picker-input-active']"
    locatorAddEntryTime = "(//button[@class = 'ant-btn ant-btn-lg'])[1]"
    locatorSelectTime = "//input[@name = 'timesArray[1].checked_in_at']"
    locatorDate = "(//div[@class = 'ant-picker-cell-inner'])[4]"
    locatorAddTimeEntry = "(//button[@class = 'ant-btn ant-btn-primary'])[1]"
