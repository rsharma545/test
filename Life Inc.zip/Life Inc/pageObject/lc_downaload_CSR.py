class DownloadCSR:

    locatorMenuParticipants = "//a[@href='/participants']"
    locatorParticipant = "//a[@href='/participants/16']"
    locatorCSRs = "(//span[@class = 'gx-link tab--3MP0J'])[4]"
    locatorVerticalDots = "(//span[@class = 'ant-dropdown-trigger material-icons gx-pointer'])[1]"
    locatorDownloadCSR = "//ul//li[text()='Download CSR']"
    
