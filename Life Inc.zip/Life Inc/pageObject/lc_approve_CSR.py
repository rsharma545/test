class ApproveCSR:

    locatorMenuApprovals = "//a[@href='/approvals?q=1']"
    locatorAllApprovals = "//a[@href='/approvals?q=all']"
    locatorViewCSRBtn = "(//span[text()='View CSR'])[1]"
    locatorApproveAll = "(//span[text()='Approve All'])[1]"
    locatorApproveForSubmission = "(//span[text()='Approve for Submission'])[1]"

