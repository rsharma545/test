class Login:
    locatorUsername = "//input[@id='username']"
    locatorPassword = "//input[@id='password']"
    locatorLoginBtn = "//span[text()='Login']"
    loginPageTitle = "//h2[@class = 'form-title']/span"

